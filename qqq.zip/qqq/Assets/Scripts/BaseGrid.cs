﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Numerics;
public class BaseGrid :MonoBehaviour
{
    public Material material;
    public int materialNum;
    public GameObject gridObj;
    
    public void Create()
    {
        gridObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
        gridObj.transform.localScale = new UnityEngine.Vector3(0.9f, 0.2f, 0.9f);
        gridObj.isStatic = true;
    }
    
    
    
}
