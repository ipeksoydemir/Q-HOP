﻿using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using UnityEngine;
using UnityEngine.UI;


public class Grids : BaseGrid
{
    public List<BaseGrid> gridObjects = new List<BaseGrid>(); // QPlatfomrlar + NPlatformlar
    public List<int> materialNumbers = new List<int>(); // -1 ise qMaterial, 0,..5 ise nMaterial (kapı)
    public List<QGrid> qGrids = new List<QGrid>(); // Tüm QGridler
    public List<int> qPlatformRowNumbers = new List<int>(); // Quantum platformlarının satır sayıları: 4,9,14,19
    public List<GameObject> qbitTextList = new List<GameObject>(); // Platformun dışında her satırda yazan matris (Başlangıçta boşluktur)
    public List<List<GameObject>> qProbLabels = new List<List<GameObject>>(); //Tüm QPlaformların olasılıkların texti
    public List<List<double>> probabilityLists = new List<List<double>>(); //Tüm olasılıklar
    public List<List<int>> qPlatformIndices = new List<List<int>>();

    public List<List<Complex>> qbits = new List<List<Complex>>(); //Tüm Karmaşıklıklar
   
    public GameObject QlabelProb;
    public GameObject QlabelName;
   

    public int platformWidth = 4;
    public int platformPiece = 4;
    public int pieceHeight = 5;
    public int platformPieceHeight;
    public int totalPlatform;
    int times = 1;
    int count = 1;
    public Light qlight;
    public GameObject QBitText;


    Material mat;
     public Material xLila ;
     public Material hLila ;
     public Material zLila ;
     public Material xMint ;
     public Material hMint ;
     public Material zMint ;
    public void CreatePlatform()
    {

        totalPlatform = platformPiece * (platformWidth * platformPieceHeight);
        platformPieceHeight = pieceHeight * platformPiece;
        var gameGrid = new GameObject("gameGrid").transform;
        gameGrid.position = new UnityEngine.Vector3(0, 0, 0);

        for (int i = 0; i < platformPieceHeight; i++)
        {
            int num = Random.Range(0, 4); //Her QPlatform satırında yenilenenecek bir random sayı
            List<int> qPlatformIndicesOneRow = new List<int>(); //Satır indisleri 
            List<double> probabilityList = new List<double>(); // Olasılıkları sıfırlar
            List<GameObject> oneProbLabels = new List<GameObject>(); // Bir satırdaki olasılık yazan textlerin listesi her satırda yenilenmelidir
            List<Complex> twoQbits = new List<Complex>(); //Her Qplatformun kendi karmaşıkklığı
   
            for (int j = 0; j < platformWidth; j++)
            {
                if ((i + 1) % pieceHeight == 0) // QPlatformlar
                {
                    QGrid qGrid = new QGrid(); 
                    qGrid.Create(); //Qgrid yaratılır

                    if(j==0)//her j'de yalnız bir kez dönmeli aksi halde liste şöyle olur:4 4 4 4 9 9 9 9 14 14 14 14 19 19 19 19
                    {
                       
                        qPlatformRowNumbers.Add(i); //4, 9, 14, 19//
                        
                    }
                       
                    qGrid.gridObj.name = "Qgrid" + i + j;  // isimlendirilir
                    qGrid.gridObj.transform.position= new UnityEngine.Vector3(j, 0, i);  // pozisyonlandırılır
                    qGrid.gridObj.transform.parent = gameGrid;  // qGrid, konumu (0,0,0) olan objenin çocuğu olarak atanır

                    qPlatformIndicesOneRow.Add(j + (i * platformWidth)); //qPlatform grid listesindeki kaçıncı eleman
                    probabilityList.Add(0.0);

                    qGrid.startingPos = num; // Başlangıç konuma bu random sayı atanır
                    ComplexValueAdd(qGrid, twoQbits); //Başlangıç konuma göre karmaşık sayı değerleri atanır
                    
                    AddQMatAndTexts(qGrid, j,i, oneProbLabels, probabilityList, qPlatformIndicesOneRow); //Quantum materyali, olasılık texti ve kapı isim textini ekler

                 
                    qGrid.alight=Instantiate(qlight); // QPlatformun üzerindeki spotlight oluşturulur
                    qGrid.alight.transform.position = new UnityEngine.Vector3(qGrid.gridObj.transform.position.x, 4, qGrid.gridObj.transform.position.z);

                   
                    materialNumbers.Add(qGrid.materialNum);
                    gridObjects.Add(qGrid);
                    qGrids.Add(qGrid);
                }
                else //Nplatformlar
                { 
                   
                    BaseGrid nGrid = new BaseGrid();
                    nGrid.Create();
                   
                    nGrid.gridObj.name = "grid" + j + i;
                    nGrid.gridObj.transform.position = new UnityEngine.Vector3(j, 0, i);

                    nGrid.gridObj.transform.Rotate(0, 180, 0); //fotoğrafın yönü yüzünden

                    nGrid.gridObj.transform.parent = gameGrid;
                    int rand = Random.Range(0, 6);

                  MaterialAdd(nGrid, rand);
                    materialNumbers.Add(nGrid.materialNum);
                    gridObjects.Add(nGrid);
                }
            }

        }
    }

    void AddQMatAndTexts(QGrid qGrid,int num,int i, List<GameObject> oneProbLabels, List<double> probabilityList, List<int> qPlatformIndicesOneRow)
    {
        MeshRenderer pMeshRenderer = qGrid.gridObj.GetComponent<MeshRenderer>();
        qGrid.qLabelProb = Instantiate(QlabelProb);
        qGrid.qLabelProb.transform.position = new UnityEngine.Vector3(qGrid.gridObj.transform.position.x - 0.3f, 0.18f, qGrid.gridObj.transform.position.z);
        
        
      
        if (num == qGrid.startingPos) //0 ile 4 arasında olan random sayıya sadece 1 tanesi eşit olabilir
        {
            qGrid.gridObj.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/1");
            qGrid.qLabelProb.GetComponent<TextMesh>().text = "1";

        }
        else // Diğerleri 0 materyalini almak zorundadır
        {
            qGrid.gridObj.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/0");
            qGrid.qLabelProb.GetComponent<TextMesh>().text = "0";

        }
        oneProbLabels.Add(qGrid.qLabelProb);
      
      
        qGrid.materialNum = -1;
        qGrid.qLabelName = Instantiate(QlabelName);
        qGrid.qLabelName.transform.position = new UnityEngine.Vector3(qGrid.gridObj.transform.position.x - 0.25f, 0.45f, qGrid.gridObj.transform.position.z + 0.4f);
        if      (num == 0) qGrid.qLabelName.GetComponent<TextMesh>().text = "|00>";
        else if (num == 1) qGrid.qLabelName.GetComponent<TextMesh>().text = "|01>";
        else if (num == 2) qGrid.qLabelName.GetComponent<TextMesh>().text = "|10>";
        else if (num == 3) qGrid.qLabelName.GetComponent<TextMesh>().text = "|11>";
        
          if (times%platformWidth==0)
        {
        qProbLabels.Add(oneProbLabels);
            GameObject qtext = Instantiate(QBitText);
            qtext.transform.position = new UnityEngine.Vector3(3.55f, 0, i);
            qtext.GetComponent<TextMesh>().text = "";  // Başlangıçta boşluktur
            qbitTextList.Add(qtext);
            probabilityLists.Add(probabilityList);
            qPlatformIndices.Add(qPlatformIndicesOneRow);

        }
        times++;
        
    }

    void ComplexValueAdd(QGrid qGrid, List<Complex> twoQbits)
    {
        if (count % platformWidth == 0)
        {
            if (qGrid.startingPos == 0)
            {
                qGrid.c00 = new Complex(1, 0);
                qGrid.c01 = new Complex(0, 0);
                qGrid.c10 = new Complex(1, 0);
                qGrid.c11 = new Complex(0, 0);
            }
            else if (qGrid.startingPos == 1)
            {
                qGrid.c00 = new Complex(0, 0);
                qGrid.c01 = new Complex(1, 0);
                qGrid.c10 = new Complex(1, 0);
                qGrid.c11 = new Complex(0, 0);
            }
            else if (qGrid.startingPos == 2)
            {
                qGrid.c00 = new Complex(1, 0);
                qGrid.c01 = new Complex(0, 0);
                qGrid.c10 = new Complex(0, 0);
                qGrid.c11 = new Complex(1, 0);
            }
            else if (qGrid.startingPos == 3)
            {
                qGrid.c00 = new Complex(0, 0);
                qGrid.c01 = new Complex(1, 0);
                qGrid.c10 = new Complex(0, 0);
                qGrid.c11 = new Complex(1, 0);
            }
            twoQbits.Add(qGrid.c00);
            twoQbits.Add(qGrid.c01);
            twoQbits.Add(qGrid.c10);
            twoQbits.Add(qGrid.c11);
            qbits.Add(twoQbits);

        }
        count++;
      

    }

      void MaterialAdd(BaseGrid nGrid, int rand)
       {
           if (rand == 0)
           {
            nGrid.gridObj.GetComponent<MeshRenderer>().material = xLila;
            nGrid.materialNum = 0;
             
           }
           else if (rand == 1)
           {
            nGrid.gridObj.GetComponent<MeshRenderer>().material = hLila;
            nGrid.materialNum = 1;
           
           }
           else if (rand == 2)
           {
            nGrid.gridObj.GetComponent<MeshRenderer>().material = zLila;
            nGrid.materialNum = 2;
         
           }
           else if (rand == 3)
           {
            nGrid.gridObj.GetComponent<MeshRenderer>().material = xMint;
            nGrid.materialNum = 3;
         
           }
           else if (rand == 4)
           {
            nGrid.gridObj.GetComponent<MeshRenderer>().material = hMint;
            nGrid.materialNum = 4;
         
           }
           else if (rand == 5)
           {
            nGrid.gridObj.GetComponent<MeshRenderer>().material = zMint;
            nGrid.materialNum = 5; 
          
           }
        
       }   
  
}

