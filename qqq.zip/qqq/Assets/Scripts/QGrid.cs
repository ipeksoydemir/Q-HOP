﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Numerics;

public class QGrid : BaseGrid 
{
   
    public int rowNum;
    public int startingPos ;
    public Light alight;
    public Complex c00, c01, c10, c11;
    public GameObject qLabelName;
    public GameObject qLabelProb;

}
