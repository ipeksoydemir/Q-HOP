﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Timer : MonoBehaviour
{

    public Text timerText;
    private float startTime;

    public float t = 10;

    void Start()
    {
        startTime = Time.time;
    }

    void Update()
    {
        bool isMoving = GameObject.Find("Player").GetComponent<PlayerController>().moving;
        string seconds = "";
        if (t > 0)
        {
            if (isMoving)

            {
                t = 10;
                t -= Time.deltaTime;
                seconds = t.ToString("f0");
            }
            //Debug.Log("hareket ettim");

            else
            {

                t -= Time.deltaTime;
                seconds = t.ToString("f0");
            }


        }
        else
        {
            seconds = "x";
            GameObject.Find("Player").GetComponent<PlayerController>().moveForward();
            t = 10;
        }
            
        timerText.text = seconds;
    }
}
