﻿using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using UnityEngine;
using UnityEngine.UI;

public class GameGrid : Grids
{

    public Grids grids = new Grids();

   
    void Start()
    {
        
        grids.CreatePlatform();

    }

    
}
